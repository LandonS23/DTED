﻿using System;
using System.IO;

using DTEDCapstone.Translator;

/*
 * Class handles the converted Cartesian data
 */
namespace DTEDCapstone.Data_Layer
{
    class CartesianData
    {
        /*The raw lat, lon, height data read from the file*/
        private MappedData[,] data;

        /*Converted Data*/
        private CartesianPoint[,] cartData;

        /*Construct object and convert the data*/
        public CartesianData(MappedData[,] data)
        {
            this.data = data;
            Convert();
        }

        /*Convert the raw data using GEOTRANS native api support*/
        public void Convert()
        {
            //Translate each point in the matrix
            cartData = new CartesianPoint[data.GetLength(0), data.GetLength(1)];
            for (int i = 0; i < cartData.GetLength(1); i++)
            {
                for (int j = data.GetLength(0) - 1; j >= 0; j--)
                {
                    cartData[j, i] = Translate.Convert(data[j, i].Latitude.Degrees, data[j, i].Longitude.Degrees, data[j, i].Elevation);
                }
            }
        }

        /*Return converted data*/
        public CartesianPoint[,] getCartesianData()
        {
            return cartData;
        }

        /*Export the converted data to a .csv*/
        public void Export(string fileName)
        {
            String myPoint;

            //Creates file if it doesn't exist, "false" will overwrite data in file if it does exist
            using (StreamWriter stream = new StreamWriter(fileName, false))
            {

                for (int i = 0; i < cartData.GetLength(0); i++)
                {
                     for (int j = 0; j < cartData.GetLength(1); j++)
                     {
                         // Grab x,y,z points to be added to CSV file
                         myPoint = cartData[i, j].X.ToString() + ", " + cartData[i, j].Y.ToString() + ", "
                               + cartData[i, j].Z.ToString();

                         stream.WriteLine(myPoint);
                     }
                }
                stream.Close();
            }
        }
    }
}