﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
///Capstone Project for DTED group
///Austin Graham
///Brandon Shaw
///Nick Von Busch
///Spencer Daniel
///Landon Sherwood
///Edward Baldwin
///Jared Hughes
///Braden Roper
///Brian Neldon
namespace DTEDCapstone
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /*Holds raw data read from the .dt1 file*/
        DTED_Data data;

        /*DTED data mapped to a matrix in lat, lon, and height in meters*/
        MappedData[,] mappedData;

        /*Data converted to X, Y, Z*/
        CartesianPoint[,] convertedData;
        
        /*Object to handle the converted data*/
        CartesianData cData;

        /*Construct the new window*/
        public MainWindow()
        {
            InitializeComponent();
        }

        /*When the import button is clicked*/
        private void import_Click(object sender, RoutedEventArgs e)
        {
            //Show the user that we are importing
            TextLabel.Content = "Importing...";

            //Open the file dialog
            OpenFileDialog fopen = new OpenFileDialog();
            fopen.RestoreDirectory = true;
            fopen.Filter = "dt1 files (*.dt1)|*.dt1";

            //When the file is selected
            if(fopen.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    //Read the file
                    FileReader reader = new FileReader(fopen.FileName);
                    reader.read(out data);

                    //Map data to the matrix
                    DataMapper mapper = new DataMapper(data);
                    mappedData = mapper.map();
                }
                catch(Exception error)
                {
                    //Show the user any error that has occured
                    System.Windows.MessageBox.Show("File is invalid. Aborting Import.");
                    TextLabel.Content = "Please select Import or Export";
                    return;
                }
            }
            else
            {
                TextLabel.Content = "Please select Import or Export";
                return;
            }

            //Convert the geodetic coordinates to cartesian
            TextLabel.Content = "Converting to Cartesian...";
            cData = new CartesianData(mappedData);
            convertedData = cData.getCartesianData();

            //Get the number of points needed for the plot
            TextLabel.Content = "Generating plot...";
            int dimensions = convertedData.GetLength(0) * convertedData.GetLength(1);
            int max = dimensions / 1000;

            //Construct the three matrices to feed to GNUPlot
            double[] X = new double[max];
            double[] Y = new double[max];
            double[] Z = new double[max];

            //Iterate through the cartesian matrix, and put only the points
            //designated by the 'max' variable into arrays to be fed to the plot
            int index = 0;
            int iterPoints = dimensions / max;
            int counter = 0;
            for (int i = 0; i < convertedData.GetLength(1); i++)
            {
                for (int j = convertedData.GetLength(0) - 1; j >= 0; j--)
                {
                    //Every max'th point
                    if (counter % iterPoints == 0)
                    {
                        X[index] = convertedData[j, i].X;
                        Y[index] = convertedData[j, i].Y;
                        Z[index] = convertedData[j, i].Z;
                        index++;
                    }
                    //If full, break out
                    if (index >= max) break;
                }
                if (index >= max) break;
            }

            //Shift the x and y points to fit onto the plot by subtracting the 
            //Earth's radius
            for (int i = 0; i < max; i++)
            {
                X[i] -= 6371392.9;
                Y[i] -= 6371392.9;
            }

            //Set the grid for the plot
            int gridDim = (int)Math.Ceiling(Math.Sqrt(max));
            Console.WriteLine(gridDim);
            GnuPlot.Set("dgrid3d " + gridDim + "," + gridDim + ",2");

            //set the range for the x,y,z axis and plot (using pm3d to map height to color)
            GnuPlot.Set("xrange["+(double)Y.Min()+":"+(double)Y.Max()+"]", "yrange["+(double)X.Min()+":"+(double)X.Max()+"]", "zrange["+(double)Z.Min()+":"+(double)Z.Max()+"]");
            GnuPlot.SPlot(Y, X, Z, "with pm3d");

            export.IsEnabled = true;
        }

        /*When the export button is clicked*/
        private void export_Click(object sender, RoutedEventArgs e)
        {
            //Construct file dialog
            TextLabel.Content = "Exporting...";
            SaveFileDialog fopen = new SaveFileDialog();

            try
            {
                //Once the file is selected, export the data
                if (fopen.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    cData.Export(fopen.FileName);
                }
            }
            catch(Exception error)
            {
                //Show user an error has occurred if needed
                System.Windows.MessageBox.Show("An error occured in export.");
            }
            //Show user if successful.
            TextLabel.Content = "Export Successful";
        }
    }
}
